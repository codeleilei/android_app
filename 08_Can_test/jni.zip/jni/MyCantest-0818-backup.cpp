#include "imax_can_CanOperation.h"
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <jni.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include "can.h"
#include <stdio.h>
#include "android/log.h"
#include <stdlib.h>
#include "libsocketcan.h"
#include <sys/socket.h>
#include <netinet/in.h>
//#include <cutils/properties.h>

#define SOCK_RAW 3

#ifndef PF_CAN
#define PF_CAN 29
#endif

#ifndef AF_CAN
#define AF_CAN PF_CAN
#endif

bool isCloseDebugInfo = false;

static const char *TAG="MyCantest";
#define LOGI(fmt, args...) isCloseDebugInfo?0:__android_log_print(ANDROID_LOG_INFO,  TAG, fmt, ##args)
#define LOGD(fmt, args...) isCloseDebugInfo?0:__android_log_print(ANDROID_LOG_DEBUG, TAG, fmt, ##args)
#define LOGE(fmt, args...) isCloseDebugInfo?0:__android_log_print(ANDROID_LOG_ERROR, TAG, fmt, ##args)

#define ADC_SET_CHANNEL _IOW('S', 0x0c, unsigned long)
struct sockaddr_can addr;
int max_socket_fd = 0;
/*
 * Class:     imax_can_CanOperation
 * Method:    canRead
 * Signature: ([Limax/can/CanNormalFrame;B)I
 */
#define CAN_EFF_FLAG 0x80000000U /* EFF/SFF is set in the MSB */
#define CAN_RTR_FLAG 0x40000000U /* remote transmission request */
#define CAN_ERR_FLAG 0x20000000U /* error frame */

JNIEXPORT jint JNICALL Java_imax_can_CanOperation_canRead
  (JNIEnv * env, jobject _object, jint _canSocket, jobjectArray _array, jint frame_count)
{
		int nbytes = 0;
		int revCount = 0;
		struct sockaddr_in myaddr;
		int len = sizeof(myaddr);
		if(_canSocket <= 0)return -1;
		struct can_frame frame;
		int k=0;
		jstring   jstr;

		fd_set rfds;
		int retval;
		struct timeval tv;
		tv.tv_sec = 0;
		tv.tv_usec = 1;
	    jclass _CanNormalFrame = env->FindClass("imax/can/CanNormalFrame");
	    jmethodID setStdId = env->GetMethodID(_CanNormalFrame,"setStdId","(I)V");
	    jmethodID setExtId = env->GetMethodID(_CanNormalFrame,"setExtId","(I)V");
	    jmethodID setIDE = env->GetMethodID(_CanNormalFrame,"setIDE","(B)V");
	    jmethodID setRTR = env->GetMethodID(_CanNormalFrame,"setRTR","(B)V");
	    jmethodID setCan_DLC = env->GetMethodID(_CanNormalFrame,"setCan_DLC","(B)V");
	    jmethodID setmData = env->GetMethodID(_CanNormalFrame,"setmData","([S)V");
	    jmethodID getmData = env->GetMethodID(_CanNormalFrame,"getmData","()[S");

//	    for(int i=0; i<byteLen; i++)
//	    	LOGI("%d:%d",i,shortbuff[i]);
//	LOGE("========================max:%d======================", max_socket_fd);
		if(_canSocket==-1){

			LOGE("Can Read Without Open");
			frame.can_id=0;
			frame.can_dlc=0;
		}else{
			FD_ZERO(&rfds);
			FD_SET(_canSocket, &rfds);
			retval = select(max_socket_fd+1 , &rfds, NULL, NULL, &tv);
		//	LOGE("========================retval:%d======================", retval);
			if (retval == -1){
				LOGE("Can Read slect error");
				frame.can_dlc=0;
				frame.can_id=0;
			}else if (retval){
				for(int z=0; z<frame_count; z++)
				{
//					LOGD("2");
					int frameLen = sizeof(frame);
					int revLen = frameLen;
					//nbytes = recvfrom(_canSocket,(&frame),sizeof(struct can_frame),0,(struct sockaddr *)(&addr),(&len));
					//nbytes = read(_canSocket,&frame,revLen);
					for(int x=0;x<10;x)
					{
						nbytes = read(_canSocket,&frame,revLen);
//						LOGE("========================nbytes:%d======================", nbytes);
						if(nbytes>0)
						{
							if(nbytes == frameLen)
							{
								break;
							}
							else if(nbytes < frameLen)
							{
								nbytes +=nbytes;
								revLen -= revLen;
							}
						}
						else
						{
							return -1;
						}
					}
//					LOGI("frame.can_id:%d",(int)frame.can_id);
					jobject obja=(jobject)env->GetObjectArrayElement(_array,z);
					jobject shortArrayObject = env -> CallObjectMethod(obja,getmData);
					if(shortArrayObject == NULL)
						return -2;
					jshortArray shortArray = (jshortArray)shortArrayObject;
					jshort *shortbuff =env->GetShortArrayElements(shortArray, 0);
					jsize  byteLen = env->GetArrayLength(shortArray);
					for(k=0;k<frame.can_dlc;k++)
					{
						shortbuff[k]=frame.data[k];
//						LOGI("frame.data%d:%d",k,frame.data[k]);
					}
					shortbuff[k]=0;
//					LOGD("revnbytes:%d",nbytes);
					if(nbytes>0)
					{
						revCount++;
						if(obja == NULL)
							return -2;
//						LOGI("dfasdfasdfasdfsadf:%d",frame.can_id <= 0x7ff);
						if ((frame.can_id & CAN_ERR_FLAG)) /* 8 digits but no errorframe?  */
							return -99;
							//cf->can_id |= CAN_EFF_FLAG;   /* then it is an extended frame */
						if(!frame.can_id & CAN_EFF_FLAG)
						{
							env -> CallVoidMethod(obja,setStdId,frame.can_id);
							env -> CallVoidMethod(obja,setExtId,0);
							env -> CallVoidMethod(obja,setIDE,(jbyte)0);
						}
						else
						{
							frame.can_id &= ~CAN_EFF_FLAG;
							env -> CallVoidMethod(obja,setExtId,frame.can_id);
							env -> CallVoidMethod(obja,setStdId,0);
							env -> CallVoidMethod(obja,setIDE,(jbyte)1);
						}
						env -> CallVoidMethod(obja,setRTR,(jbyte)0);
						env -> CallVoidMethod(obja,setCan_DLC,(jbyte)frame.can_dlc);
						env -> CallVoidMethod(obja,setmData,shortArray);

//						jmethodID getmData = env->GetMethodID(_CanNormalFrame,"getmData","()[S");
//					    jobject shortArrayObject = env -> CallObjectMethod(obja,getmData);
//					    jshortArray shortArray = (jshortArray)shortArrayObject;
//					    jshort *bytebuff =env->GetShortArrayElements(shortArray, 0);
//					    jsize  byteLen = env->GetArrayLength(shortArray);
//					    for(int i=0; i<byteLen; i++)
//					    	LOGI("====%d:%d",i,bytebuff[i]);

						env->SetShortArrayRegion(shortArray, 0, byteLen,shortbuff );
						env->ReleaseShortArrayElements(shortArray,shortbuff,0);
						env->DeleteLocalRef(obja);
						env->DeleteLocalRef(shortArrayObject);
					}
				}
			}else{
				frame.can_dlc=0;
				frame.can_id=0;
			}

		}
		env->DeleteLocalRef(_CanNormalFrame);
//		for(int i=0; i< frame.can_dlc; i++)
//		{
//			LOGD("%x:%x",i,frame.data[i]);
//		}
//		LOGD("read nbytes=%d",frame.can_dlc);
//		LOGD("can_id = %d",frame.can_id);
		return   revCount;
}

/*
 * Class:     imax_can_CanOperation
 * Method:    canWrite
 * Signature: (Limax/can/CanNormalFrame;)I
 */

JNIEXPORT jint JNICALL Java_imax_can_CanOperation_canWrite
  (JNIEnv *env, jobject _object, jint _canSocket, jobject obj)
{
		int nbytes;
		struct can_frame frame;
		if(_canSocket <= 0)return -1;
		jclass _CanNormalFrame = env->GetObjectClass(obj);
		//jclass _CanNormalFrame = env->FindClass("imax/can/CanNormalFrame");
		int sendID = 0;
	    if(_CanNormalFrame == NULL)
	        return -1; //can not find class Studnet
	    jmethodID getStdId = env->GetMethodID(_CanNormalFrame,"getStdId","()I");
	    jmethodID getExtId = env->GetMethodID(_CanNormalFrame,"getExtId","()I");
	    jmethodID getIDE = env->GetMethodID(_CanNormalFrame,"getIDE","()B");
	    jmethodID getRTR = env->GetMethodID(_CanNormalFrame,"getRTR","()B");
	    jmethodID getCan_DLC = env->GetMethodID(_CanNormalFrame,"getCan_DLC","()B");
	    jmethodID getmData = env->GetMethodID(_CanNormalFrame,"getmData","()[S");

	    unsigned int stdId = env -> CallIntMethod(obj,getStdId);
	    unsigned int extId = env -> CallIntMethod(obj,getExtId);
	    unsigned char IDE = env -> CallByteMethod(obj,getIDE);
	    unsigned char RTR = env -> CallByteMethod(obj,getRTR);
	    unsigned short can_DLC = env -> CallByteMethod(obj,getCan_DLC);

	    jobject shortArrayObject = env -> CallObjectMethod(obj,getmData);
	    jshortArray shortArray = (jshortArray)shortArrayObject;
	    jshort *bytebuff =env->GetShortArrayElements(shortArray, 0);
	    jsize  byteLen = env->GetArrayLength(shortArray);
//	    for(int i=0; i<can_DLC; i++)
//    		LOGI("%d:%d",i,bytebuff[i]);
//		LOGI("stdId:%d,extId:%d,IDE:%d,RTR:%d,can_DLC:%d",stdId,extId,IDE,RTR,can_DLC);
	    if(1 == IDE)
	    {
			if (!(extId & CAN_ERR_FLAG)) /* 8 digits but no errorframe?  */
				extId|= CAN_EFF_FLAG;   /* then it is an extended frame */
	    	sendID = extId;

	    }else if(0 == IDE)
	    {
	    	sendID = stdId;
	    }
		frame.can_id = sendID;
		frame.can_dlc = can_DLC;
//	    char send_data[8];
//	    memset(send_data,0,8);
//	    LOGI("df121as");
		memset(frame.data,0,8);
		for(int i=0; i<can_DLC; i++)
		{
			frame.data[i] = 0xff & bytebuff[i];
		}
		//fuck ����strcpy ʹ������,���������������RFID��strcpy��char*,unsigned char*)������
		//strcpy((char *)frame.data,send_data);
//		LOGI("frame.id:%x",frame.can_id);
//	    for(int i=0; i<8; i++)
//	    	LOGI("%d:%x",i,frame.data[i]);
	    nbytes = write(_canSocket,&frame,sizeof(can_frame));
//		LOGI("nbytes:%d,frame.id:%x",nbytes,frame.can_id);
//		frame.can_dlc = 1;
//		frame.can_id = 0x5A1;
//		frame.data[0] = 0x1 ;
//		nbytes = sendto(_canSocket,&frame,sizeof(struct can_frame),0,(struct sockaddr*)&addr,sizeof(addr));
		env->SetShortArrayRegion(shortArray, 0, byteLen, bytebuff);
		env->ReleaseShortArrayElements(shortArray,bytebuff,0);
		env->DeleteLocalRef(_CanNormalFrame);
		env->DeleteLocalRef(shortArrayObject);

		return nbytes;
}

/*
 * Class:     imax_can_CanOperation
 * Method:    startCan
 * Signature: (ILjava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_imax_can_CanOperation_startCan
  (JNIEnv *env, jobject _object, jint _bitrate, jstring  _canName)
{
    LOGI("SocketCan  start");
    int err;
    int val = _bitrate;
    jboolean iscopy = false;
    const char *name = env->GetStringUTFChars(_canName, &iscopy);
    err = can_set_bitrate(name, val);

    if (err < 0)
    {
    	LOGI("failed to set bitrate of %s to %i\n",name,val);
    	 return false;
     }

     if (can_do_start(name) < 0)
     {
    	 LOGI("%s: failed to start\n",name);
    	 return false;
     }
     env->ReleaseStringUTFChars(_canName,name);
     return true;
}
JNIEXPORT jboolean JNICALL Java_imax_can_CanOperation_downCan
  (JNIEnv *env, jobject _object,  jint canSocket ,jstring _canName)
{
    //LOGE("SocketCan : stop ");
    jboolean iscopy = false;
    const char *name = env->GetStringUTFChars(_canName, &iscopy);
    if(canSocket != -1)
    	close(canSocket);
    canSocket=-1;
    if (can_do_stop(name) < 0)
    {
    	//LOGI("%s: failed to start\n",name);
        return false;
    }
    env->ReleaseStringUTFChars(_canName,name);
    return true;
}
/*
 * Class:     imax_can_CanOperation
 * Method:    reStartCan
 * Signature: (ILjava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_imax_can_CanOperation_reStartCan
  (JNIEnv *env, jobject _object, jint canSocket , jint _bitrate, jstring _canName)
{
	Java_imax_can_CanOperation_downCan(env,_object,canSocket,_canName);
	Java_imax_can_CanOperation_startCan(env,  _object,  _bitrate,  _canName);
}

/*
 * Class:     imax_can_CanOperation
 * Method:    downCan
 * Signature: (Ljava/lang/String;)Z
 */


/*
 * Class:     imax_can_CanOperation
 * Method:    openCan
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_imax_can_CanOperation_openCan
  (JNIEnv *env, jobject, jstring _canName)
{
		struct ifreq ifr;

		jboolean iscopy = false;
		const char *name = env->GetStringUTFChars(_canName, &iscopy);

		/* Opening device */
		int canfd = socket(PF_CAN,SOCK_RAW,CAN_RAW);
//		LOGI("========================max_socket_fd1:%d======================", max_socket_fd);
		if(canfd > max_socket_fd)
		{
			max_socket_fd = canfd;
		}
//		LOGI("========================max_socket_fd2:%d======================", max_socket_fd);
		if(canfd == -1)
		{
			//LOGE("Can Write Without Open");
			return -1;
		}

		strcpy((char *)(ifr.ifr_name),name);
		ioctl(canfd,SIOCGIFINDEX,&ifr);

		addr.can_family = AF_CAN;
		addr.can_ifindex = ifr.ifr_ifindex;
		bind(canfd,(struct sockaddr*)&addr,sizeof(addr));
		 env->ReleaseStringUTFChars(_canName,name);
		return canfd;
}

/*
 * Class:     imax_can_CanOperation
 * Method:    closeCan
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_imax_can_CanOperation_closeCan
  (JNIEnv *env, jobject, jint _canSocket)
{
		if(_canSocket!=-1)
			close(_canSocket);
		_canSocket=-1;
		//LOGD("close can0");
}

JNIEXPORT void JNICALL Java_imax_can_CanOperation_isCloseDebugInfo
  (JNIEnv *env, jobject obj, jboolean isCose)
{
	isCloseDebugInfo = isCose;
	LOGD("Java_imax_can_CanOperation_isCloseDebugInfo");
}
